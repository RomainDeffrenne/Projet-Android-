package com.example.manga.utils;

public class Constants {

    public class General {
        public static final String LOG_TAG = "manga_app";
    }

    public class Login {
        public static final String EXTRA_LOGIN = "extraLogin";
    }

    public class Preferences {
        public static final String SHARED_PREFERENCES_FILE_NAME = "mangaSharedPrefs";
        public static final String PREF_LOGIN = "prefLogin";
        public static final String PREF_PASSWORD = "prefPassword";
    }

}
